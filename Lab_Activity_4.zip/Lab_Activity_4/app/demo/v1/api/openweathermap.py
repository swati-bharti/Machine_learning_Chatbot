import pyowm

# API_KEY for openweather 
owm = pyowm.OWM('272f1cfbee4fc37b9f8610d2c065e122')

def get_weather_forecast(location):
    
    # method to get weather manager object 
    mgr = owm.weather_manager()

    # to get temperature in celsius
    weather_temp = mgr.weather_at_place(location).weather
    
    # we get a dictionary of temperature with (temp,temp_min,temp_max..)in celsius
    temp_dict_celsius = weather_temp.temperature('celsius')
    
    # selection of only temp from the dictionary 
    temp_in_celsius= temp_dict_celsius['temp']
    
    # to retrieve weather from a particular location  
    observation = mgr.weather_at_place(location)  
    weather = observation.weather
    
    # to get the weather status
    short_weather_status = weather.status
    
    # to get the detailed weather status
    detailed_weather_status = weather.detailed_status

    # return statement
    return_statement = 'We have {} in {} with temperature of {} celsius'.format(detailed_weather_status, location ,temp_in_celsius )
    
    return return_statement
