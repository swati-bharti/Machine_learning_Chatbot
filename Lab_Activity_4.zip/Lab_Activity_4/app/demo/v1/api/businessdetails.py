import requests
from .credentials import YELP_TOKEN


def get_business_details(search_query,latitude,longitude):
    
    # to get the result from yelp
    result = requests.get('https://api.yelp.com/v3/businesses/search?term={}&latitude={}&longitude={}'.format(search_query,latitude,longitude),
                      headers={'Authorization': YELP_TOKEN })
    result = result.json()
    
    # gives the total number of restaurants
    total_number_of_restaurants = result['total']
    
    # list to store name of restaurants and phone number
    name_of_restaurants = []
    phone_number_of_restaurants = []
    
    print('total number of restaurants is', total_number_of_restaurants)
    print('######################################################################')

    # to insert values into the list 
    for i in range(0,20):
        name_of_restaurants.append(result['businesses'][i]['name'])
        phone_number_of_restaurants.append(result['businesses'][i]['phone'])
        print(i)
        print(result['businesses'][i]['name'])
        print(result['businesses'][i]['phone'])
        print('######################################################################')
        
    # return statement
    return dict(zip(name_of_restaurants,phone_number_of_restaurants))

