# Authorization key for openweather
TOKEN = "Bearer SJV7EZTKUGKXSPTW2MJDBL32DHWVAVUR"

# API_KEY for Yelp with authorization 
YELP_TOKEN = "Bearer hTBPQQ4V9xI37o_njSprEBQOrsNeaIgSyzHrYd4k6cu37NaB3d5xyAXa1Hl3GWSXgEX0IWq-IlpCdHlzC5qdfwWX5SFFTB7dARzekXUUk5VhyzIDvxhwKAD3PUOeX3Yx"
