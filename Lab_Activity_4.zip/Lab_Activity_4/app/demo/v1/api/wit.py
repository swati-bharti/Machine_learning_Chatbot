from .openweathermap import get_weather_forecast
from .credentials import TOKEN
from .businessdetails import get_business_details
import requests

def ask_wit(expression):
    result = requests.get('https://api.wit.ai/message?v=20201102&q={}'.format(expression),
                          headers={'Authorization': TOKEN})
    jsonResult = result.json()
    try:
        
        # to check weather forecast of a particular location
        if jsonResult['intents'][0]['name'] == 'GetWeatherForecast':
            location = jsonResult['entities']["wit$location:location"][0]['resolved']['values'][0]['name']
##        if jsonResult['entities']['intent'][0]['value'] == 'GetWeatherForecast':
##            location = jsonResult['entities']['location'][0]['value']
            print("location detected: {}".format(location))
            answer = get_weather_forecast(location)
            print(answer)
            return answer
            
        # to check the restaurant names of a particualr location
        if jsonResult['intents'][0]['name'] == 'FindRestaurant':
            location = jsonResult['entities']["wit$location:location"][0]['resolved']['values'][0]['name']
##        if jsonResult['entities']['intent'][0]['value'] == 'FindRestaurant':
##            location = jsonResult['entities']['location'][0]['value']
            search_query = jsonResult['entities']["wit$local_search_query:local_search_query"][0]['value']
##            search_query = jsonResult['entities']['local_search_query'][0]['value']
            latitude = jsonResult['entities']["wit$location:location"][0]['resolved']['values'][0]['coords']['lat']
            longitude = jsonResult['entities']["wit$location:location"][0]['resolved']['values'][0]['coords']['long']
##            latitude = jsonResult['entities']['location'][0]['resolved']['values'][0]['coords']['lat']
##            longitude = jsonResult['entities']['location'][0]['resolved']['values'][0]['coords']['long']
            print("Business location detected: {}".format(location))
            print("Business latitude detected: {}".format(latitude))
            print("Business longitude detected: {}".format(longitude))
            print("Business to be searched: {}".format(search_query))
            answer = get_business_details(search_query, latitude, longitude)
            print(answer)
            return answer

    except KeyError as err:
        answer = "I dont understand :("
        return answer
    
        
